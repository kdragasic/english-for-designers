function openPortfolio(item) {
    alert('Portfolio item ' + item + ' clicked! Add your navigation logic here.');
}

window.onload = function() {
    const greeting = document.querySelector('.greeting');
    greeting.textContent = 'Hello, Welcome to My Website!';
};
